<?php
require_once __DIR__ . '/vendor/autoload.php';
 use SharePilotV2\Components\Website;
 $website = new Website();
 $website->start();