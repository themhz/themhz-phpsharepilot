    <div class="w3-row custom-padding-45">
        <div class="w3-container w3-teal">
            <h1>Welcome to Share Pilot</h1>
        </div>
        <div class="w3-container">
            <div class="w3-panel w3-leftbar">
                <p><i class="fa fa-quote-right w3-xxlarge"></i><br>
                    <i class="w3-serif w3-xlarge">Welcome to Share Pilot

                    </i>
                </p>
            </div>
        </div>
    </div>
