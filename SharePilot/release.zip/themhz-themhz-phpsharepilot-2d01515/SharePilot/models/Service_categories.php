<?php

namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;

class Service_categories extends Model
{
    public function GetTable()
    {
        return "service_categories";
    }
}

