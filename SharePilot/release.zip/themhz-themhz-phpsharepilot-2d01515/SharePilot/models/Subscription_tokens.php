<?php
namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;

class Subscription_tokens extends Model
{
    public function GetTable()
    {
        return "subscription_tokens";
    }
}

