<?php
namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;

class Subscription_types extends Model
{
    public function GetTable()
    {
        return "subscription_types";
    }
}

