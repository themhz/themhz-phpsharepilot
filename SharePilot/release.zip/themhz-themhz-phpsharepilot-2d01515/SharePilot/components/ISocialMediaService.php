<?php
namespace SharePilotV2\Components;

interface ISocialMediaService
{
    public function post($messages);
}