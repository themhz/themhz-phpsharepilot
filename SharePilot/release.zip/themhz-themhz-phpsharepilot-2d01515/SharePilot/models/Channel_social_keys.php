<?php

namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;

class Channel_social_keys extends Model
{
    public function GetTable()
    {
        return "channel_social_keys";
    }
}

