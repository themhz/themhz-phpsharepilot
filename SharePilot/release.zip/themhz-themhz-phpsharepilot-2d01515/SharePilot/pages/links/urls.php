<div style="display: flex; justify-content: space-between; align-items: center; padding: 0 24px;">
    <h1 class="w3-text-teal">Links</h1>
    <button id="sortButton" onclick="sortUrls()" class="w3-button w3-teal w3-large"><i class="fas fa-sort"></i> Sort</button>
</div>
<div class="w3-container">
    <ul class="w3-ul w3-card-4" id="urls">
        <!-- Url items will be appended here -->
    </ul>
</div>
