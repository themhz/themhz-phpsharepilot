<?php
namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;

class Subscriptions extends Model
{
    public function GetTable()
    {
        return "subscriptions";
    }
}

