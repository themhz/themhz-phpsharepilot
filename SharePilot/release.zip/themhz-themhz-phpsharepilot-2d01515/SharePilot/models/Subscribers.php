<?php
namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;

class Subscribers extends Model
{
    public function GetTable()
    {
        return "subscribers";
    }
}

