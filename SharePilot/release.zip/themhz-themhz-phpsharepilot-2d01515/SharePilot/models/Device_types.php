<?php
namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;

class Device_types extends Model
{
    public function GetTable()
    {
        return "device_types";
    }
}

