<?php

namespace SharePilotV2\Models;
use SharePilotV2\Components\Model;
class Settings extends Model
{
    public function GetTable()
    {
        return "settings";
    }
}
